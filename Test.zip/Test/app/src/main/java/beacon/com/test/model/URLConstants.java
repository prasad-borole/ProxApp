package beacon.com.test.model;

/**
 * Created by abhishek on 11/6/16.
 */
public class URLConstants {

    public static final String AWS_URL = "http://ec2-54-201-105-65.us-west-2.compute.amazonaws.com:8000";
}
