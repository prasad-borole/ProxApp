package beacon.com.test.fragment;


import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import beacon.com.test.R;
import beacon.com.test.service.LoginService;

public class LoginFragment extends Fragment {
    EditText email;
    EditText password;
    View rootView;
    LoginService loginService;

    public LoginFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_login, container, false);
        loginService = new LoginService();

        Button signupButton = (Button) rootView.findViewById(R.id.btn_signup);
        Button loginButton = (Button) rootView.findViewById(R.id.btn_login);

        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                email =  (EditText) rootView.findViewById(R.id.input_email);
                password =  (EditText) rootView.findViewById(R.id.input_password);
                String username = email.getText().toString().trim();
                String passwd = password.getText().toString().trim();
                loginService.registerUser(username, passwd);

            }
        });


        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                email =  (EditText) rootView.findViewById(R.id.input_email);
                password =  (EditText) rootView.findViewById(R.id.input_password);
                String username = email.getText().toString().trim();
                String passwd = password.getText().toString().trim();
                loginService.loginUser(username, passwd);

            }
        });


        // Inflate the layout for this fragment
        return rootView;
    }


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }


    @Override
    public void onDetach() {
        super.onDetach();
    }
}